<?php
namespace app\api\controller\v1;
// use think\Validate;
// use app\api\validate\TestValidate; //引用模块
use app\api\validate\IDMustBePostiveInt; //自定义验证规则
use app\api\model\Banner as BannerModel;//别名
class Banner
{
    public function getBanner($id)
    {   
    (new IDMustBePostiveInt())->goCheck();
    $banner = BannerModel::getBannerByID($id);
    return $banner;
    }
}


