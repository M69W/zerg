<?php
namespace app\api\validate;

use think\Validate;

class IDMustBePostiveInt extends BaseValidate{
    public $rule = [
    
          "id" => "require|isPositoveInteger"
    ];
    //自定义验证规则
    protected function isPositoveInteger($value,$rule = "",$data = "",$field = ""){
    if (is_numeric($value) && is_int($value + 0) && ($value + 0) > 0) {
            return true;
            echo $value,$data,$field,$rule;
        }
        else{
            return $field.'必须是正整数';
            echo $value,$data,$field,$rule;
        }
    }
}


