<?php
namespace app\api\validate;
use think\Exception;
use think\Request;
use think\Validate;
class BaseValidate extends Validate
{
  public function goCheck(){
    //获取http传人的参数
    //对这些参数做检验
    $request = Request::instance();
    $params = $request ->param();//获取当前请求的所有变量
     $result = $this -> check($params); //使用check方法校验是否符合
     if(!$result){
         $error = $this ->error;
         throw new Exception($error); //抛出异常
      }
      else{
          return true;
      }
  }
}